//package com.codeup.meta.models;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface Ads extends JpaRepository<Ad, Long>{
//
//    Long getId();
//
//    String getTitle();
//
//    String getDescription();
//}
