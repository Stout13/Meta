//package com.codeup.meta.models;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface Posts extends PostRepository{
//
//    Long getId();
//
//    String getTitle();
//
//    String getDescription();
//}
