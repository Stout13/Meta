package com.codeup.meta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MetaApplicationTests {

    @Test
    void contextLoads() {
    }

}
